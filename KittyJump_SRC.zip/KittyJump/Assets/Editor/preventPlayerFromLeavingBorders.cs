using UnityEngine;
using Unity.Mathematics;

public class preventPlayerFromLeavingBorders : MonoBehaviour
{
    public Camera gameCamera;
    private Vector2 screenBounds;

    void Start()
    {
        
    }

    void Update()
    {
        screenBounds = gameCamera.ScreenToWorldPoint(new Vector3(Screen.width, Screen.height, gameCamera.transform.position.z));
        Vector2 viewPoint = transform.position;
        viewPoint.x = math.clamp(viewPoint.x, screenBounds.x * -1, screenBounds.x);
        transform.position = viewPoint;
    }
}
