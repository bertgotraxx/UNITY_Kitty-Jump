using Unity.Mathematics;
using UnityEngine;

public class GenerateNewPlatforms : MonoBehaviour
{
    public GameObject basicPlatformPrefab;
    public GameObject Player;
    public Camera gameCamera;
    private Vector2 screenBounds;
    private float heightLevel;
    //private bool onCooldown = false;
    
    void Start()
    {
        screenBounds = gameCamera.ScreenToWorldPoint(new Vector3(Screen.width, Screen.height, gameCamera.transform.position.z));
        heightLevel = Player.transform.position.y + 4f;
        for (int i = 0; i < 2; i++)
        {
            Vector2 randomVector = new Vector2(
                UnityEngine.Random.Range(screenBounds.x * -1, screenBounds.x),
                UnityEngine.Random.Range((screenBounds.y - 4.8f) + (i * math.PI), (screenBounds.y - 4f) + (i * math.PI)));
            GameObject basicPlatform = Instantiate(basicPlatformPrefab, randomVector, transform.rotation);
            basicPlatform.GetComponent<selfDestroy>().enabled = true;
        }

        for (int i = 0; i < 2; i++)
        {
            Vector2 randomVector = new Vector2(
                UnityEngine.Random.Range(screenBounds.x * -1, screenBounds.x),
                UnityEngine.Random.Range((screenBounds.y + 0.8f) + (i * math.PI), (screenBounds.y + 1.8f) + (i * math.PI)));
            //Instantiate(basicPlatformPrefab, randomVector, transform.rotation);
            GameObject basicPlatform = Instantiate(basicPlatformPrefab, randomVector, transform.rotation);
            basicPlatform.GetComponent<selfDestroy>().enabled = true;
        }
    }


    void Update()
    {
        screenBounds = gameCamera.ScreenToWorldPoint(new Vector3(Screen.width, Screen.height, gameCamera.transform.position.z));
        //Debug.Log(screenBounds);
        if (Player.transform.position.y > heightLevel)
        {
            Debug.Log("NEW PLATFORM CREATED");
            heightLevel = Player.transform.position.y + 5f;
            for (float i = 0; i < 2; i++)
            {
                Vector2 randomVector = new Vector2(
                UnityEngine.Random.Range(screenBounds.x * -1, screenBounds.x),
                UnityEngine.Random.Range((screenBounds.y + 1f) + (i * math.PI), (screenBounds.y + 2.5f) + (i * math.PI)));
                //Instantiate(basicPlatformPrefab, randomVector, transform.rotation);
                GameObject basicPlatform = Instantiate(basicPlatformPrefab, randomVector, transform.rotation);
                basicPlatform.GetComponent<selfDestroy>().enabled = true;
            }
        }
    }
}
