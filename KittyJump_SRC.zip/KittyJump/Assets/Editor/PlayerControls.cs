using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerControls : MonoBehaviour
{

    public Rigidbody2D RB;
    public int SPEED;
    public int JUMP_POWER;
    public InputAction InputAction;

    bool onGround = true;

    Vector2 moveDirection = Vector2.zero;

    private void OnEnable()
    {
        InputAction.Enable();
    }
    private void OnDisable()
    {
        InputAction.Disable();
    }

    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        float moveX = Input.GetAxis("Horizontal");
        //float moveY = Input.GetAxis("Vertical");

        onGround = Physics2D.CircleCast(transform.position, 0.5f, Vector2.down, 0.05f);

        //moveDirection = new Vector2(moveX,moveY);
        moveDirection = InputAction.ReadValue<Vector2>();

        RB.linearVelocityX = moveDirection.x * SPEED;

        if (onGround)
        {

            RB.linearVelocityY = JUMP_POWER;
            //if (moveDirection.y > 0)
            //{
            //    //RB.AddForceY(moveDirection.y * JUMP_POWER);
            //    RB.linearVelocityY = moveDirection.y * JUMP_POWER;
            //    //onGround = false;
            //}
        }
    }
}
