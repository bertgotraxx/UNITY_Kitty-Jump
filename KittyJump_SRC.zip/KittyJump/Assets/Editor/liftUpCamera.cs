using UnityEngine;

public class liftUpCamera : MonoBehaviour
{

    public Camera gameCamera;
    void Start()
    {
        
    }

    private void OnTriggerEnter2D(Collider2D plrObject)
    {
        if (plrObject.tag == "Player")
        {
            Rigidbody2D camerasRB = gameCamera.GetComponent<Rigidbody2D>();
            camerasRB.linearVelocityY = 10f;
        }
    }

    private void OnTriggerExit2D(Collider2D plrObject)
    {
        if (plrObject.tag == "Player")
        {
            Rigidbody2D camerasRB = gameCamera.GetComponent<Rigidbody2D>();
            camerasRB.linearVelocityY = 0f;
        }
    }

    void Update()
    {
        
    }
}
